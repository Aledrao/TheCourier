# Car-Demo

A simple car demo project to help you make your own cars in godot 4.0 .

Features:
       A basic car 
       Dynamic camera
       GLTF models of cars and wheel
       Uses inheritance to let you quickly make multiple versions easily 
       
       
